---
uwpart_version: "1.0"
part_id: rent-roll-210
section: rent_roll
collection_member: true
---

## Rent Roll {#rent_roll}

```json uw:section=rent_roll v=1
{
  "_meta": {
    "section": "rent_roll",
    "provenance": {
      "source": "system/uwmd",
      "resolution": "source_document",
      "actor": "example-kit",
      "agent_id": null,
      "agent_version": null,
      "notes": null
    },
    "quality": {
      "flags": [],
      "partial": false,
      "provisional": false
    },
    "lifecycle": {
      "revision": 1,
      "superseded": false
    }
  },
  "unit_id": "210",
  "tenant_name": "Anchor Tenant LLC",
  "monthly_rent": 15400,
  "lease_start": "2024-03-01",
  "lease_end": "2034-02-28"
}
```

